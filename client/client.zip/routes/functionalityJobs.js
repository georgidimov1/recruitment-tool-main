var express = require('express');
var router = express.Router();
var services = require('../services/services.js')
let endpoint = 'jobs'

router.get('/', function(req, res, next) {
    services.getAll(endpoint)
    .then(x => x.json())
    .then(x => res.render(endpoint, { title: 'JOBS' , jobs: x}))
    
  });
  router.get('/create', function(req, res, next) {
    res.render('create', {action:`create`});
  });
  router.post('/create', function(req, res, next) {
    services.postJobsData (endpoint, req.body)
    .then(x=>console.log(x.status))
    .catch(Error)
    res.redirect('/jobs');
  });
  router.get('/delete/:_id', function(req, res, next) {
    services.delete (endpoint, req.params._id)
    .then(x=>console.log(x.status))
    .catch(Error)
      res.redirect('/jobs');
  });
  router.get('/update/:_id', function(req, res, next) {
    services.getOne(endpoint, req.params._id)
    .then(x => x.json())
    .then(x => res.render('createCandidate', { action:`${x._id}`, title: x.title , description: x.description}))
   });
  router.post('/update/:_id', function(req, res, next) {
    console.log('yes');
    services.edit (endpoint,req.params._id, req.body)
    .then(x=>console.log(x.status))
    .catch(Error)
    res.redirect('/jobs');
  });
  router.get('/details/:_id', function(req, res, next) {
    services.getOne(endpoint, req.params._id)
    .then(x => x.json())
    .then(x => res.render('details', { title: x.title , description: x.description}))
   });

  module.exports = router;