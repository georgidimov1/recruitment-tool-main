var express = require('express');
var router = express.Router();
var services = require('../services/services.js')
let endpoint = 'candidates';
router.get('/', function(req, res, next) {
    services.getAll(endpoint)
    .then(x => x.json())
    .then(x => res.render('candidates', { title: 'Candidates' , candidates: x}))
    
  });
  router.get('/create', function(req, res, next) {
    res.render('createCandidates', {action:`create`});
  });
  router.post('/create', function(req, res, next) {
    console.log(req.body)
    services.postJobsData (endpoint, req.body)
    .then(x=>console.log(x.status))
    .catch(Error)
    res.redirect('/candidates');
  });
  router.get('/delete/:_id', function(req, res, next) {
    services.delete (endpoint, req.params._id)
    .then(x=>console.log(x.status))
    .catch(Error)
      res.redirect('/candidates');
  });
  router.get('/update/:_id', function(req, res, next) {
    services.getOne(endpoint, req.params._id)
    .then(x => x.json())
    .then(x => res.render('createCandidates', { action:`${x._id}`, firstName: x.firstName , lastName: x.lastName, email: x.email}))
   });
  router.post('/update/:_id', function(req, res, next) {
    console.log('yes');
    services.edit (endpoint,req.params._id, req.body)
    .then(x=>console.log(x.status))
    .catch(Error)
    res.redirect('/candidates');
  });
  router.get('/details/:_id', function(req, res, next) {
    services.getOne(endpoint, req.params._id)
    .then(x => x.json())
    .then(x => res.render('candidatesDetails', { firstName: x.firstName , lastName: x.lastName, email: x.email}))
   });
  module.exports = router;